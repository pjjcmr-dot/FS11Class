const TAX_RATE = 0.1;

const itemPrice = 10_000;
const tax = itemPrice * TAX_RATE;

console.log(`상품 가격은 ${itemPrice}원, 부가세는 ${tax}원 입니다.`);

let mutate = '100';
mutate = 100;

const value = 100;

// 쓰지 않는다!
// var a;
// console.log(a); // undefined
// var a = 100_000;
