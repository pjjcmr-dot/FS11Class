// 조건의 type은 boolean
// if (조건) {
//   // 조건이 참(true)일때, 실행이 되는 코드
// } else {
//   // 조건이 거짓(false) 일때 실행이 되는 코드
// }

const height = 120;

if (height >= 140) {
  console.log('탑승 가능!');
} else {
  console.log('탑승 불가능!');
}