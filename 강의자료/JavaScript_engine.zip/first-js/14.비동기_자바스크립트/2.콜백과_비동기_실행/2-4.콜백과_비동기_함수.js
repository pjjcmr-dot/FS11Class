// console.log('프로그램 시작');

// setTimeout(() => {
//   console.log('안녕하세요');
// }, 3000);

// console.log('프로그램 진행 중...');

console.log('1');

setTimeout(() => console.log('2'), 0);

console.log('3');

setInterval(() => {
  console.log('1초마다 실행');
}, 1000);
