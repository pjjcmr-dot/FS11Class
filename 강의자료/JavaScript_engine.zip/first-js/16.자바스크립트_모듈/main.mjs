import { add, devide } from './lib/math/index.mjs';

const result = add(10, 2);
console.log(result);
