// 스타일 다루기 실습
const task = document.querySelector('.task');

// task.style.textDecoration = 'line-through';
// task.style.backgroundColor = '#f0f0f0';

// const box = document.querySelector('#box');
// box.style.fontSize = '20px';
// box.style.color = 'blue';
// box.style.marginTop = '10px';

// task.classList.add('done', 'completed', 'highlight');

task.classList.add('done');

// task.classList.remove('done');

task.classList.toggle('done');
