// 노드 삭제와 이동하기 실습
const taskList = document.querySelector('#task-list');

// taskList.remove();

// console.log('taskList', taskList);

// document.body.append(taskList);

// 특정 요소 삭제하기

// taskList.children[0].remove();

const completed = document.querySelector('.completed');

taskList.append(completed);
