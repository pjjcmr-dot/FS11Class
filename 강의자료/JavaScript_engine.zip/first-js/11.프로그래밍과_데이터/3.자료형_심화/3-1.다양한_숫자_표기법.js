const bigNumber = 10_000_000_000;

const billionaire = 10_000_000_000;
const num = 1e10;

const hex1 = 0xff; // 255
const hex2 = 0xff;
const hex3 = 0x10; // 16

const octal = 0o377;

console.log(octal);

const binary = 0b11111111; // 255

console.log(binary);
